package com.example.rpcclient;

import java.util.HashMap;
import java.util.Map;

public class user {
    private String nomeUsuario;
    private int quantidadePts;
    private int numPerg;
    private String respCliente;

    public user(String nomeUsuario) {
        this.nomeUsuario = nomeUsuario;
        this.quantidadePts = 0;
        this.numPerg = 0;
        this.respCliente = null;
    }

    public String getNomeUsuario() {
        return nomeUsuario;
    }

    public void setNomeUsuario(String nomeUsuario) {
        this.nomeUsuario = nomeUsuario;
    }

    public int getQuantidadePts() {
        return quantidadePts;
    }

    public void setQuantidadePts(int quantidadePts) {
        this.quantidadePts = quantidadePts;
    }

    public int getNumPerg() {
        return numPerg;
    }

    public void setNumPerg(int numPerg) {
        this.numPerg = numPerg;
    }

    public String getRespCliente() {
        return respCliente;
    }

    public void setRespCliente(String respCliente) {
        this.respCliente = respCliente;
    }

    /**
     * Exporta os campos como um Map para envio via XML-RPC.
     */
    public Map<String, Object> toMap() {
        Map<String, Object> map = new HashMap<>();
        map.put("nome_usuario", nomeUsuario);
        map.put("quantidade_pts", quantidadePts);
        map.put("num_perg", numPerg);
        map.put("resp_cliente", respCliente);
        return map;
    }
}