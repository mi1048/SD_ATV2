package com.example.rpcclient;

import org.apache.xmlrpc.client.XmlRpcClient;
import org.apache.xmlrpc.client.XmlRpcClientConfigImpl;

import java.net.URL;
import java.util.Map;
import java.util.Scanner;

public class cliente {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("=== MENU DE OPÇÕES ===");
        System.out.println("1 - Matemática (porta 8000)");
        System.out.println("2 - Sistemas Distribuídos (porta 8001)");
        System.out.println("3 - Filmes (porta 8002)");
        System.out.print("Escolha uma opção (1/2/3): ");
        String opcao = scanner.nextLine().trim();

        int porta;
        switch (opcao) {
            case "1": porta = 8000; break;
            case "2": porta = 8001; break;
            case "3": porta = 8002; break;
            default:
                System.out.println("Opção inválida. Encerrando.");
                scanner.close();
                return;
        }

        try {
            XmlRpcClientConfigImpl config = new XmlRpcClientConfigImpl();
            config.setServerURL(new URL("http://localhost:" + porta));
            config.setEnabledForExtensions(true);
            config.setConnectionTimeout(60000);
            config.setReplyTimeout(60000);

            XmlRpcClient client = new XmlRpcClient();
            client.setConfig(config);

            System.out.print("Digite seu nome: ");
            String nomeUsuario = scanner.nextLine().trim();
            user user = new user(nomeUsuario);

            boolean fim = false;
            while (!fim) {
                // Envia o usuário atual ao servidor
                @SuppressWarnings("unchecked")
                Map<String, Object> response = (Map<String, Object>) client.execute(
                        "processar_interacao", new Object[]{ user.toMap() }
                );

                // Exibe a mensagem retornada
                System.out.println(response.get("mensagem"));

                // Atualiza campos do usuário com o que o servidor retornou
                user.setQuantidadePts((Integer) response.get("quantidade_pts"));
                user.setNumPerg((Integer) response.get("num_perg"));

                // Checa fim
                fim = Boolean.TRUE.equals(response.get("fim"));
                if (fim) break;

                // Lê próxima resposta
                System.out.print("Sua resposta: ");
                String resposta = scanner.nextLine().trim().toUpperCase();
                user.setRespCliente(resposta);
            }
        } catch (Exception e) {
            System.err.println("Erro ao conectar/comunicar: " + e.getMessage());
            e.printStackTrace();
        } finally {
            scanner.close();
        }
    }
}